/*:
 ## Exercise - Variables
 
 Declare a variable `schooling` and set it to the number of years of school that you have completed. Print `schooling` to the console.
 */
var schooling = 15
print(schooling)



schooling = 20
print (schooling)




print 
//: [Previous](@previous)  |  page 3 of 10  |  [Next: App Exercise - Step Count](@next)
